  #Q10. Write a program to convert a binary number into a decimal number without using any library function.
#Input a binary number :1010101
#Expected Output :
#The Binary Number : 1010101
#The equivalent Decimal Number : 85

A=int(input("give the number for getting the decimal representation:"))
def binary_To_decimal(A):
  dec=0
  count=0
  while(A!=0):
    digit=A%10
    dec=dec+digit*pow(2,count)
    A=A//10
    count=count+1
  return dec
print(binary_To_decimal(A))
