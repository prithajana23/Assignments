#Q14. Write a program which computes the factorial of a given number. Read the number from the input and write the factorial in the output.
n=int(input("give the number for getting factorial:"))
fact=1
if(n<0):
  print("the factorial is defined for negative number")
elif(n==0):
  print("the factorial of the number 0 is 1")
else:
    for i in range(1,n+1):
     fact=fact*i
     fact
print(fact)

