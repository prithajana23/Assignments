#Q3.Write a program to perform the following tasks on the given dictionary.
mark = {'A': 60, 'B': 50, 'C': 80, 'D': 70, 'E': 40}
# Add a key-value pair: ‘F’: 30 and print the resulting dict.
mark.update({'F':'30'})
print(mark)
# Check whether the key ‘X’ exists in the dict and print the result.
if mark.get('X') is not None:
  print("the key exists in the list")
else:
  print("the key does not exist in the dictionary")
# Print the list of all the keys in the dict.
print(mark.keys())
# Print the list of all the values in the dict.
print(mark.values())
# Sort the dict by value and print the new dict.
import operator
mark={'A': 60, 'B': 50, 'C': 80, 'D': 70, 'E': 40, 'F': 30}
sorted_mark=dict(sorted(mark.items(),key=operator.itemgetter(1),reverse=True))
print(sorted_mark)

