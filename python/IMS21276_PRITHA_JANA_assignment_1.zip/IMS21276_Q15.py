#Q15. Write a program which accepts a sequence of comma-separated numbers from console and generate a list and a tuple which contains every number. Suppose the followinginput is supplied to the program:
#34,67,55,33,12,98

a=int(input("the 1st element:"))
b=int(input("the 2nd element:"))
c=int(input("the 3rd element:"))
d=int(input("the 4th element:"))
e=int(input("the 5th element:"))
f=int(input("the 6th element:"))
print("['{0}', '{1}','{2}','{3}','{4}','{5}']".format(a,b,c,d,e,f))
print("('{0}', '{1}','{2}','{3}','{4}','{5}')".format(a,b,c,d,e,f))



