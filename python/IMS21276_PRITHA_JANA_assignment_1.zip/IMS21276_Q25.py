#Q25. Write a Python function ‘integrate(f, a, b)’ to integrate a function ‘f’ between ‘a’ and ‘b’. Use the following formula to compute the integral,
#Define a function f(x) = 2x^3 + 4x^2 + 1 and use the above function to find the integral between 0 and 1. In the output print values of the numerical integral as well as the exact analytical integral.
def fun(x):
  return 2*(x**3)+4*(x**2)+1
def integration(fun,a,b):
  return ((b-a)/6)*((fun(a))+4*(fun((a+b)/2))+fun(b))

a=int(input("the lower limit"))
b=int(input("the upper limit"))
print(integration(fun,a,b))
   
