#Q4. Write a program that accepts three integers and find the maximum of three.
#Test Data :
#Input the first integer: 25
#Input the second integer: 35
#Input the third integer: 15
#Expected Output:
#Maximum value of three integers: 35
a=input("the first integer :")
b=input("the second integer :")
c=input("the third integer :")
test_data=[a,b,c]
print("The maximum value of the list is ",max(test_data))

