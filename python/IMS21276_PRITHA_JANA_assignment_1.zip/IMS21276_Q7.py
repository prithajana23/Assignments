#Q7. Write a program to display the multiplication table of a given integer.
#Test Data :
#Input the number (Table to be calculated) : 15
#Expected Output :
#15 X 1 = 15
#...
#...
#15 X 10 = 150

A=int(input("For which number you want the multiplication table:"))
for i in range(0,11):
  B=A*i
  print(A,'X',i,"=",B)
  
  
  
