#Q6. Write a program to calculate the root of a Quadratic Equation.
#Test Data : 1 5 7
#Expected Output :
#Root are imaginary;
#No solution.
import numpy as np
a=int(input("the value of the first  coefficient"))
b=int(input("the value of the second coefficient"))
c=int(input("the value of the third coefficient"))
print("the quadratic equation is",a,'x^2 +',b,'x+',c,"=0")
K=b**2-4*a*c
#R1=(-b+np.sqrt(K))/2*a
#R2=(-b-np.sqrt(K))/2*a
#R=-b/2*a

if(K<0):
  print("roots are imaginary and have no solution")
elif(K==0):
  print("roots are real and equal and are",-b/2*a)
else:
  print("roots are real and different and are given by R_1=",(-b+np.sqrt(K))/2*a,"R_2=",(-b-np.sqrt(K))/2*a)


