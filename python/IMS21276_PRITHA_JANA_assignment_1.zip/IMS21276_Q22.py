#Q22. The Fibonacci Sequence is computed based on the following formula:
#f(n) =0, n = 0
#f(n) =1, n = 1
#f(n) =f(n − 1) + f(n − 2), n > 1
#Write a program to compute the value of f(n) with a given n input by console.
n1=0
n2=1
i=0
n=int(input("upto which term you want the Fibonacci sequence:"))
if(n==1):
  print("f(n)=1")  
elif(n<=0):
  print("please write a positive number")
else:
  print("the fibonacci sequence will be")
  while(i<n):
    print(n1)
    nth=n1+n2
    n1=n2
    n2=nth
    i=i+1
    
