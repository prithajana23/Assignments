#Q23. Write a program using list comprehension to print the Fibonacci Sequence in comma separated form with a given n input by console.
n1=0
n2=1
i=0
n=int(input("upto which term you want the Fibonacci sequence:"))
if(n==1):
  print("f(n)=1")  
elif(n<=0):
  print("please write a positive number")
else:
  print("the fibonacci sequence will be")
  while(i<n):
    print(n1,end=',')
    nth=n1+n2
    n1=n2
    n2=nth
    i=i+1
    
