#Q2.Write a program to perform the suggested tasks related to the given list.
my_list = [10, 1.5, -20, "Python", "100", "C", "Snake"]
print(my_list)
# Remove the element at index 5 and print the new list.
del my_list[5]
print(my_list)
# Remove the element "C" and print the new list.
my_list = [10, 1.5, -20, "Python", "100", "C", "Snake"]
my_list.remove("C")
print(my_list)
# Add an element "C++" at the end of the list and print the new list.
my_list=my_list+["C++"]
print(my_list)
# Remove all the ‘string’ elements from the list.
del my_list[3:7]
print(my_list)
# Find the largest number in the list from previous step.
print(max(my_list))

