#Q12. Write a program to count the frequency of each element of an array.
#Test Data :
#Input the number of elements to be stored in the array :3
#Input 3 elements in the array :
#element - 0 : 25
#element - 1 : 12
#element - 2 : 43
#Expected Output :
#The frequency of all elements of an array :
#25 occurs 1 times
#12 occurs 1 times
#43 occurs 1 times



import numpy as np
a=int(input("the 1st element:"))
b=int(input("the 2nd element:"))
c=int(input("the 3rd element:"))

A=[a,b,c]
print(a,"occurs",A.count(a),'times')
print(b,"occurs",A.count(b),'times')
print(c,"occurs",A.count(c),'times')


