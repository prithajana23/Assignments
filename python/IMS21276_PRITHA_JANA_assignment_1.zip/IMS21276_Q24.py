 #Q24. Write a program which prints all permutations of [1,2,3]
a=int(input("Enter first number:"))  
b=int(input("Enter second number:"))  
c=int(input("Enter third number:"))  
def combination(l):
  l.append(a)
  l.append(b)
  l.append(c)
  for i in range(3):
      for j in range(3):
          for k in range(3):
            if(i!=j and j!=k and i!=k):
              print(l[i],l[j],l[k])
combination([])


