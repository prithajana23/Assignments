#Q20. A robot moves in a plane starting from the original point (0,0). The robot can move toward UP, DOWN, LEFT and RIGHT with a given steps. The trace of robot movement is shown as the following:
#UP 5
#DOWN 3
#LEFT 3
#RIGHT 2
#The numbers after the direction are steps. Write a program to read the steps from input and when done, compute its distance from the original point. Print the distance in the output.
import numpy as np
def dist(movement):
  ini_pos=[0,0]
  for move in movement:
    dir=move.split()
    if(dir[0]=="UP"):
      ini_pos[0]+=int(dir[1])
    elif(dir[0]=="DOWN"):
      ini_pos[0]-=int(dir[1])
    elif(dir[0]=="RIGHT"):
      ini_pos[1]+=int(dir[1])
    elif(dir[0]=="LEFT"):
      ini_pos[1]-=int(dir[1])
  return np.sqrt(ini_pos[0]**2+ini_pos[1]**2) 

def main():
  movement = ("UP 5", "DOWN 3", "RIGHT 2","LEFT 3")
  total_dist=dist(movement)
  print(total_dist) 

if __name__ == '__main__':
    main()

