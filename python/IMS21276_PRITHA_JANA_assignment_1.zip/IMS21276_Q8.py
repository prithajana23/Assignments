#Q8. Write a program to display the n terms of harmonic series 1 + 1/2 + 1/3 + . . . + 1/n and
#their sum.
#Test Data :
#Input the number of terms : 5
#Expected Output :
#1/1 + 1/2 + 1/3 + 1/4 + 1/5
#Sum of Series upto 5 terms : 2.283334


import numpy as np
N=int(input("the number upto which terms you want the sum of the harmonic series :"))
sum=0
for i in range(1,N+1):
  sum=sum+(1/i)
print("The sum of the number upto 1+1/2+.....+1/",N," is ",round(sum,6))


