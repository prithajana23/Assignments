#Q16. Write a program that accepts a comma separated sequence of words as input and prints the words in a comma-separated sequence after sorting them alphabetically. Suppose the following input is supplied to the program: without,hello,bag,world
#Then, the output should be:
#bag,hello,without,world

a=input("please input the word:")
b=input("please input the word:")
c=input("please input the word:")
d=input("please input the word:")

A=[a,b,c,d]
A.sort()
print(A)

