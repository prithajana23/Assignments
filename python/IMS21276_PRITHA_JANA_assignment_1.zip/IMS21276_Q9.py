#Q9. Write a program to convert a decimal number into binary without using any library function.
#Test Data :
#Enter a number to convert : 25
#Expected Output :
#The Binary of 25 is 11001.

A=int(input("give the number for getting the binary representation:"))
B=[]
while(A>0):
  b=A%2
  B.append(b)
  A=A//2
B.reverse()
print("The binary representation of the number is:")
for i in B:
  print(i,end='')
