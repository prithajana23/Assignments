#Q1. Write a program to perform the suggested tasks on the given string.
my_string = "Python is a programming language, that lets you work quickly"
# Print the last character
print(len(my_string))
print(my_string[59])
# Write a statement that prints the , (comma) character
print(my_string.find(","))
print(my_string[32])
# Print the index of the ‘w’ character.
print(my_string.find("w"))
# Find and print the number of occurrences of the character ‘a’
print(my_string.count("a"))
# Convert all the letters into upper case and print the string
print(my_string.upper())
# Split string into two parts using the , (comma) as the delimiter and
W=my_string.split(",")
# print the two parts
print(W)
