#Q13. Write a program to sort elements of array in ascending order.
#Test Data :
#Input the size of array : 5
#Input 5 elements in the array :
#element - 0 : 2
#element - 1 : 7
#element - 2 : 4
#element - 3 : 5
#element - 4 : 9
#Expected Output :
#Elements of array in sorted ascending order:
#2 4 5 7 9

a=int(input("the 1st element:"))
b=int(input("the 2nd element:"))
c=int(input("the 3rd element:"))
d=int(input("the 4th element:"))
e=int(input("the 5th element:"))
A=(a,b,c,d,e)
print(sorted(A))

