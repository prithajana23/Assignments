#Q17. Write a program which accepts a sequence of comma separated 4 digit binary numbers as its input and then check whether they are divisible by 5 or not. The numbers that are divisible by 5 are to be printed in a comma separated sequence. Example:
#0100,0011,1010,1001
#Then the output should be:
#1010

A=int(input("give the number for getting the decimal representation:"))
B=int(input("give the number for getting the decimal representation:"))
C=int(input("give the number for getting the decimal representation:"))
D=int(input("give the number for getting the decimal representation:"))

def binary_To_decimal(A):
  dec=0
  count=0
  while(A!=0):
    digit=A%10
    dec=dec+digit*pow(2,count)
    A=A//10
    count=count+1
  return dec
L=[binary_To_decimal(A),binary_To_decimal(B),binary_To_decimal(C),binary_To_decimal(D)]
print(L)
for x in L:
  if(x%5==0):
    print(x)
F=[]
while(x>0):
  b=x%2
  F.append(b)
  x=x//2
F.reverse()
print("The binary representation of the number is:")
for i in F:
  print(i,end='')
  
