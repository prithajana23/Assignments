#Q5. Write a program to read an amount of money (integer value) and break the amount into smallest possible number of bank notes.
#Test Data :
#Input the amount: 375
#Expected Output:
#There are:
#3 Note(s) of 100.00
#1 Note(s) of 50.00
#1 Note(s) of 20.00
#0 Note(s) of 10.00
#1 Note(s) of 5.00
#0 Note(s) of 2.00
#0 Note(s) of 1.00

A=int(input("the amount of money:"))
import math
n=math.floor(A/100)
l=A-100*n
m=math.floor(l/50)
k=l-m*50
j=math.floor(k/20)
x=k-j*20
i=math.floor(x/10)
y=x-i*10
z=math.floor(y/5)
v=y-z*5
h=math.floor(v/2)
u=v-h*2
w=math.floor(u/1)
print("The number of 100 notes are:",n)
print("The number of 50 notes are:",m)
print("The number of 20 notes are:",j)
print("The number of 10 notes are:",i)
print("The number of 5 coins are:",z)
print("The number of 2 coins are:",h)
print("The number of 1 coins are:",w)

