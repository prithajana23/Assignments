#1. Briefly explain the method of “Gaussian Elimination with Partial pivoting". Write a program to implement the algorithm and run it on the test system of linear equations.
#Put the explanation part as comments at the top of the file. Enter the test system directly into the code (that is, do not make the code to read the system from any input file.)
#In the output, first print the system of linear equation that you used as test system, and then print the solution obtained by the method.


import numpy as np
import os
import sys

nrows =int(input("Give the number of rows:#can input #4:"))
mcols=int(input("Give the number of columns: can put #5:"))
a1=int(input("the coefficient of the 1st variable in the 1st equation:"))
b1=int(input("the coefficient of the 2nd variable in the 1st equation:"))
c1=int(input("the coefficient of the 3rd variable in the 1st equation:"))
d1=int(input("the coefficient of the 4th variable in the 1st equation:"))
e1=int(input("the coefficient of the 5th variable in the 1st equation:"))
a2=int(input("the coefficient of the 1st variable in the 2nd equation:"))
b2=int(input("the coefficient of the 2nd variable in the 2nd equation:"))
c2=int(input("the coefficient of the 3rd variable in the 2nd equation:"))
d2=int(input("the coefficient of the 4th variable in the 2nd equation:"))
e2=int(input("the coefficient of the 5th variable in the 2nd equation:"))
a3=int(input("the coefficient of the 1st variable in the 3rd equation:"))
b3=int(input("the coefficient of the 2nd variable in the 3rd equation:"))
c3=int(input("the coefficient of the 3rd variable in the 3rd equation:"))
d3=int(input("the coefficient of the 4th variable in the 3rd equation:"))
e3=int(input("the coefficient of the 5th variable in the 3rd equation:"))
a4=int(input("the coefficient of the 1st variable in the 4th equation:"))
b4=int(input("the coefficient of the 2nd variable in the 4th equation:"))
c4=int(input("the coefficient of the 3rd variable in the 4th equation:"))
d4=int(input("the coefficient of the 4th variable in the 4th equation:"))
e4=int(input("the coefficient of the 5th variable in the 4th equation:"))

print(a1,'x1+',b1,'x2+',c1,'x3+',d1,'x4+',e1,'x5')
print(a2,'x1+',b2,'x2+',c2,'x3+',d2,'x4+',e2,'x5')
print(a3,'x1+',b3,'x2+',c3,'x3+',d3,'x4+',e3,'x5')
print(a4,'x1+',b4,'x2+',c4,'x3+',d4,'x4+',e4,'x5')

A=np.array([[a1,b1,c1,d1,e1],[a2,b2,c2,d2,e2],[a3,b3,c3,d3,e3],[a4,b4,c4,d4,e4]])
print("The required augmented matrix is:",A)
if nrows+1!= mcols:
  print("Invalid system size")

def Gauss_Eli_partial_pivoting(A):
  n,m=A.shape
  if(n+1 != m):
    print("invalid size")
  for j in range(n):
    pivot=A[j,j]
    pivot_done=False
    if np.isclose(pivot,0.0,atol=1.0E-12):
      for k in range(j+1,n):
        if not np.isclose(A[k,j],0.0,atol=1.0E-12):
          for p in range(n+1):
            x=A[j,p]
            A[j,p]=A[k,p]
            A[k,p]=x
          pivot_done=True
          break
      if(k==n):
        print("the system has no solution")
        return None
    if pivot_done: continue
    for i in range(j+1,n):
      ratio=A[i,j]/pivot
    for k in range(j,n+1):
      A[i,k]=A[i,k]-A[j,k]*ratio
  x=A[:,n]
  for i in range(n-1,-1,-1):
      for j in range(i+1,n):
        x[i]=x[i]-A[i,j]*x[j]
      x[i]=x[i]/A[i,i]
  return x
sols=Gauss_Eli_partial_pivoting(A)
print(sols)

